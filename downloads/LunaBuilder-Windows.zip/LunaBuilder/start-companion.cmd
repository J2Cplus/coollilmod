@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0start-companion.ps1" %*
pause
